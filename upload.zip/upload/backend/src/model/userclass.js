class User{
    constructor(obj){
        this.username=obj.username;
        this.password=obj.password;
    }
}
module.exports=User;