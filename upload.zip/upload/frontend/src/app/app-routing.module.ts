import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {RegistercomponentComponent} from './registercomponent/registercomponent.component';
import {LogincomponentComponent} from './logincomponent/logincomponent.component';
import {UpdatecomponentComponent} from './updatecomponent/updatecomponent.component';
import {AdmincomponentComponent} from './admincomponent/admincomponent.component';

const routes: Routes = [
  {path:"register",component:RegistercomponentComponent},
  {path:"login",component:LogincomponentComponent},
  {path:"update/:newpassword",component:UpdatecomponentComponent},
  {path:"admin",component:AdmincomponentComponent},
 
  {path:"**",redirectTo:"register",pathMatch:"full"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
