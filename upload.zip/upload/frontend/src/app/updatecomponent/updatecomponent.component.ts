import { Component, OnInit } from '@angular/core';
import {  FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UpdatecomponentService } from './updatecomponent.service';
@Component({
  selector: 'app-updatecomponent',
  templateUrl: './updatecomponent.component.html',
  styleUrls: ['./updatecomponent.component.css']
})
export class UpdatecomponentComponent implements OnInit {
  errorMessage: String;
  successMessage: String;
  updateForm: FormGroup
  constructor(private updateservice:UpdatecomponentService,private fb:FormBuilder) { }

  ngOnInit() {
    this.updateForm=this.fb.group({
      username:["",[]],
      password:["",[Validators.required,Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\W).*$/)]],
      newpassword:["",[Validators.required,Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\W).*$/)]]
     
    })
  }

  update() {
    
    
    this.successMessage=null;
    this.errorMessage=null;
    let formObj={username:this.updateForm.value.username,password:this.updateForm.value.password};
    let newpassword=this.updateForm.value.newpassword;
    this.updateservice.updateservice(formObj,newpassword).subscribe(
      (response)=>{console.log(response.message);this.successMessage=response.message;},
      (err)=>{this.errorMessage=err.error.message;}
    )
  }
}
