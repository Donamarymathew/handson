import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class UpdatecomponentService {
  errorMessage: String;
  
  constructor(private http:HttpClient) { }
  updateservice(formData:any,newpassword): Observable<any> {
    console.log("service");
    return this.http.put<any>("http://localhost:1050/update/"+newpassword,formData);
   }
}
