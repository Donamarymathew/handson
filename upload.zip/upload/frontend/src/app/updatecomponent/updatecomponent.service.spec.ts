import { TestBed } from '@angular/core/testing';

import { UpdatecomponentService } from './updatecomponent.service';

describe('UpdatecomponentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UpdatecomponentService = TestBed.get(UpdatecomponentService);
    expect(service).toBeTruthy();
  });
});
