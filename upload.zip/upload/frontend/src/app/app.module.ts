import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistercomponentComponent } from './registercomponent/registercomponent.component';
import { HttpClientModule } from "@angular/common/http";
import {RegistercomponentService} from './registercomponent/registercomponent.service';
import { LogincomponentComponent } from './logincomponent/logincomponent.component';
import { UpdatecomponentComponent } from './updatecomponent/updatecomponent.component';
import {UpdatecomponentService} from './updatecomponent/updatecomponent.service';
import {LogincomponentService} from './logincomponent/logincomponent.service';
import { AdmincomponentComponent } from './admincomponent/admincomponent.component';
import { DisplaycomponentComponent } from './displaycomponent/displaycomponent.component';
import {AdmincomponentService} from './admincomponent/admincomponent.service';
import {DisplaycomponentService} from './displaycomponent/displaycomponent.service';
import {DeleteService} from './displaycomponent/delete.service';
@NgModule({
  declarations: [
    AppComponent,
    RegistercomponentComponent,
    LogincomponentComponent,
    UpdatecomponentComponent,
    AdmincomponentComponent,
    DisplaycomponentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule, FormsModule,
  ],
  providers: [RegistercomponentService,UpdatecomponentService,LogincomponentService,AdmincomponentService,DisplaycomponentService,DeleteService],
  bootstrap: [AppComponent]
})
export class AppModule { }
