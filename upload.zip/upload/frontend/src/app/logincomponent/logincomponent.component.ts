import { Component, OnInit } from '@angular/core';
import {  FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LogincomponentService } from './logincomponent.service';
@Component({
  selector: 'app-logincomponent',
  templateUrl: './logincomponent.component.html',
  styleUrls: ['./logincomponent.component.css']
})
export class LogincomponentComponent implements OnInit {
  errorMessage: String;
  successMessage: String;
  loginForm: FormGroup
  constructor(private loginService:LogincomponentService,private fb:FormBuilder) { }

  ngOnInit() {
    this.loginForm=this.fb.group({
      username:["",[]],
      password:["",[Validators.required,Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\W).*$/)]]
     
    })
  }

  login() {
    
    
    this.successMessage=null;
    this.errorMessage=null;
    
    this.loginService.loginservice(this.loginForm.value).subscribe(
      (response)=>{console.log(response.message);this.successMessage=response.message;},
      (err)=>{this.errorMessage=err.error.message;}
    )
  }

}
