import { TestBed } from '@angular/core/testing';

import { LogincomponentService } from './logincomponent.service';

describe('LogincomponentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LogincomponentService = TestBed.get(LogincomponentService);
    expect(service).toBeTruthy();
  });
});
