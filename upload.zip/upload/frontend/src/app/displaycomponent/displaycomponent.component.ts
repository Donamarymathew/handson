import { Component, OnInit,Input } from '@angular/core';
import { DisplaycomponentService } from './displaycomponent.service';
import {DeleteService} from './delete.service';
@Component({
  selector: 'app-displaycomponent',
  templateUrl: './displaycomponent.component.html',
  styleUrls: ['./displaycomponent.component.css']
})
export class DisplaycomponentComponent implements OnInit {

errorMessage: String;
successMessage: String;
errormsg:String;
successmsg:String;
userdata;
  constructor(private displayService:DisplaycomponentService,private deleteService:DeleteService) { }

  ngOnInit() {
    console.log("display");
    this.successMessage=null;
    this.errorMessage=null;
    
    
    this.displayService.displayservice().subscribe(
      (response)=>{
        
      this.userdata=response;},
      (err)=>{this.errorMessage=err.error.message;}
    )
  }
  delete(username,password){
    console.log(username,password);
    this.deleteService.deleteservice(username,password).subscribe(
      (response)=>{
        console.log("fff");
      this.successmsg=response.message;
    this.userdata=this.userdata.filter((ele)=>{
      console.log(ele);
      ele.username!=username; 
      console.log(this.userdata);
    })
    },
      (err)=>{this.errormsg=err.error.message;}
    )
  }

}
