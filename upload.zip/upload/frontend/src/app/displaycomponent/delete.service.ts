import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class DeleteService {

  errorMessage: String;
  
  constructor(private http:HttpClient) { }
  deleteservice(username,password): Observable<any> {
  
    return this.http.delete<any>("http://localhost:1050/delete/"+username+"/"+password);
   }
}
