import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AdmincomponentService {
  errorMessage: String;
  url = "http://localhost:1050/admin";
  
  constructor(private http:HttpClient) { }

  adminservice(formData:any): Observable<any> {
    
    return this.http.post<any>(this.url,formData);
   }
}
