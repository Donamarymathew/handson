import { Component, OnInit } from '@angular/core';
import {  FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AdmincomponentService } from './admincomponent.service';
@Component({
  selector: 'app-admincomponent',
  templateUrl: './admincomponent.component.html',
  styleUrls: ['./admincomponent.component.css']
})
export class AdmincomponentComponent implements OnInit {
  flag:boolean=false;
  errorMessage: String;
  successMessage: String;
  loginForm: FormGroup;
 
  constructor(private adminService:AdmincomponentService,private fb:FormBuilder) { }

  ngOnInit() {
   
    this.loginForm=this.fb.group({
      username:["",[]],
      password:["",[Validators.required,Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\W).*$/)]]
     
    })
  }

  login() {
    
    
    this.successMessage=null;
    this.errorMessage=null;
    
    this.adminService.adminservice(this.loginForm.value).subscribe(
      (response)=>{
        this.flag=true;
        console.log(this.flag)
        this.successMessage=response.message;},
      (err)=>{this.errorMessage=err.error.message;}
    )
  }


}
