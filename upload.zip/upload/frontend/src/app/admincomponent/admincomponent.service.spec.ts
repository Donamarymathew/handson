import { TestBed } from '@angular/core/testing';

import { AdmincomponentService } from './admincomponent.service';

describe('AdmincomponentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AdmincomponentService = TestBed.get(AdmincomponentService);
    expect(service).toBeTruthy();
  });
});
