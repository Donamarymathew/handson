import { Component, OnInit } from '@angular/core';
import {  FormGroup, FormBuilder, Validators } from '@angular/forms';
import { RegistercomponentService } from './registercomponent.service';
@Component({
  selector: 'app-registercomponent',
  templateUrl: './registercomponent.component.html',
  styleUrls: ['./registercomponent.component.css']
})
export class RegistercomponentComponent implements OnInit {

  errorMessage: String;
  successMessage: String;
  registerForm: FormGroup
  constructor(private registerservice:RegistercomponentService,private fb:FormBuilder) { }

  ngOnInit(): void {
    this.registerForm=this.fb.group({
      username:["",[]],
      password:["",[Validators.required,Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\W).*$/)]]
     
    })
  }

  



  register() {
    
    
    this.successMessage=null;
    this.errorMessage=null;
    
    this.registerservice.registerservice(this.registerForm.value).subscribe(
      (response)=>{console.log(response.message);this.successMessage=response.message;},
      (err)=>{this.errorMessage=err.error.message;}
    )
  }


}

