import { TestBed } from '@angular/core/testing';

import { RegistercomponentService } from './registercomponent.service';

describe('RegistercomponentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RegistercomponentService = TestBed.get(RegistercomponentService);
    expect(service).toBeTruthy();
  });
});
