import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RegistercomponentService {
 
  errorMessage: String;
  url = "http://localhost:1050/register";
  
  constructor(private http:HttpClient) { }
 
  registerservice(formData:any): Observable<any> {
    
   return this.http.post<any>(this.url,formData);
  }

}
